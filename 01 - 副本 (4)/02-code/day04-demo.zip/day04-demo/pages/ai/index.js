// pages/ai/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    gender: '',
    age: '',
    beauty: '',
    glass: ''
  },

  // 上传图片给ai接口做颜值检测
  detectImage (path) {
    // 缓存this
    let that = this;
    wx.uploadFile({
      // 上传的地址（ai地址）
      url: 'https://ai.qq.com/cgi-bin/appdemo_detectface',
      // 要上传的文件的路径
      filePath: path,
      // 该name的值用于提供给服务器获取图片信息（服务器更加该名称获取图片）
      name: 'image_file',
      // 获取接口的返回结果数据
      success: function(res) {
        // console.log(typeof res.data);
        // 把res.data字符串转化为json对象
        let obj = JSON.parse(res.data);
        let info = obj.data.face[0];
        // console.log(info);
        // 更新页面数据必须使用setData
        that.setData({
          gender: info.gender,
          age: info.age,
          beauty: info.beauty,
          glass: info.glass
        });
      }
    })
  },

  // 选择图片
  selectImage () {
    // 缓存this
    let that = this;
    // console.log('image');
    // 选择图片
    wx.chooseImage({
      success: function(res) {
        // console.log(res)
        let path = res.tempFiles[0].path;
        // console.log(path);
        // 这里的this指向不对
        that.detectImage(path);
      }
    });
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})