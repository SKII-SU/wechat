<template>
  <div class="search-bar">
    <div class="search-input">
      <navigator url='/pages/search/main'>
        <icon type='search' color='#999'/>
        <span>搜索</span>
      </navigator>
    </div>
  </div>
</template>
<style scoped lang='scss'>
.search-bar {
  background-color: #EB4450;
  padding: 20rpx;
  .search-input {
    background-color: #fff;
    text-align: center;
    icon {
      vertical-align: middle;
    }
  }
} 
</style>
